function controller(event){
    if(event.key == "Enter"){
        if(runWorker==0){
            run();
            runSound.play();
            updateScore();
            moveBackground();
            flameMargins.forEach(createFlames);
        }
    }    
    if(event.key == " "){

        if(jumpWorker == 0){
            if(runWorker != 0){
                clearInterval(runWorker);
                runSound.pause();
                jump();
                jumpSound.play();

            }

        }

    }

}
        

var runImageNumber = 1;
var runWorker = 0;
var runSound = new Audio("run.mp3");
runSound.loop = true;

function run(){

    runWorker = setInterval(()=>{

        runImageNumber = runImageNumber + 1;

        if(runImageNumber==9){
            runImageNumber = 1;
        }
        document.getElementById("boy").src = "run" + runImageNumber + ".png";

    },100);

}

var jumpImageNumber = 1;
var jumpWorker = 0;
var jumpSound = new Audio("jump.mp3")
var jumpMargin = 500;

function jump(){

    jumpWorker = setInterval(()=>{

        jumpImageNumber = jumpImageNumber + 1;

        if(jumpImageNumber < 8){
            jumpMargin = jumpMargin - 10;
            document.getElementById("boy").style.marginTop = jumpMargin + "px";
        }
        if(jumpImageNumber > 7){
            jumpMargin = jumpMargin +10;
            document.getElementById("boy").style.marginTop = jumpMargin + "px";
        }

        if(jumpImageNumber == 13){
            jumpImageNumber = 1;
            clearInterval(jumpWorker);
            run();
            runSound.play();
            jumpWorker = 0;
        }

        document.getElementById("boy").src = "jump" + jumpImageNumber + ".png"

    },100);

}

var score = 0;
var scoreWorker = 0;

function updateScore(){

    scoreWorker = setInterval(

        ()=>{

            if(score == 1400){
                runSound.pause();
                alert("You Won!");
                window.location.reload();
            }

            score = score + 10;
            document.getElementById("score").innerHTML = score;

        },100

    );

}

var backgroundX = 0;
var backgroundWorker = 0;

function moveBackground(){

    backgroundWorker = setInterval(

        ()=>{
            
            backgroundX = backgroundX - 10;
            document.getElementById("background").style.backgroundPositionX = backgroundX + "px";

        },50

    );

}

var flameMargins = [500,1000,1500,2000,2500];  
var flameWorker = 0;

function createFlames(x){

    var i = document.createElement("img");
    i.src = "flame.gif";
    i.className = "flame";
    i.style.marginLeft = x + "px";
    document.getElementById("background").appendChild(i);

    flameWorker = setInterval(

        ()=>{
            
            if(flameWorker != 0){
                x = x - 10;
                i.style.marginLeft = x + "px";
            }

            if(x == 80){
                if(jumpWorker == 0){
                    clearInterval(runWorker);
                    clearInterval(scoreWorker);
                    clearInterval(backgroundWorker);
                    clearInterval(flameWorker);
                    flameWorker = 0;
                    dead();
                    runSound.pause();
                    deadSound.play();
                }
            }

        },50

    );

}

var deadImage = 1;
var deadWorker = 0;
var deadSound = new Audio("dead.mp3");

function dead(){

    deadWorker =setInterval(

        ()=>{

            deadImage = deadImage + 1;

            if(deadImage == 11){
                deadImage = 1;
                clearInterval(deadWorker)
                alert("Game Over! Press Ok to Restart");
                window.location.reload();
            }

            document.getElementById("boy").src = "dead" + deadImage + ".png";

        },100

    );

}

document.addEventListener("keydown", function(event) {

    if (event.key === "Enter") {
        const instructionMenu = document.getElementById('instructionMenu');
        instructionMenu.style.display = "none";
        startGame();

    }
});

function startGame() {
    
    const instructionMenu = document.getElementById('instructionMenu');
    instructionMenu.style.display = "none";
    
    if (runWorker == 0) {
        run();
        runSound.play();
        updateScore();
        moveBackground();
        flameMargins.forEach(createFlames);
    }
}